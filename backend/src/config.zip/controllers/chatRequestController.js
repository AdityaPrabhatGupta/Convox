import { ChatRequest, Chat, User } from "../models/index.js";
import { getReceiverSocketId, io } from "../socket/socket.js";

const populateChatById = async (chatId) =>
  Chat.findById(chatId)
    .populate("users", "name email profilePic")
    .populate({
      path: "latestMessage",
      populate: {
        path: "sender",
        select: "name email profilePic",
      },
    });

const findDirectChat = async (firstUserId, secondUserId) =>
  Chat.findOne({
    isGroupChat: false,
    users: { $all: [firstUserId, secondUserId] },
  });

const populateRequestById = async (requestId) =>
  ChatRequest.findById(requestId)
    .populate("sender", "name email profilePic")
    .populate("receiver", "name email profilePic");

export const sendChatRequest = async (req, res) => {
  try {
    const senderId = req.user._id;
    const { receiverId } = req.body;

    if (senderId.toString() === receiverId) {
      return res
        .status(400)
        .json({ message: "You cannot send a request to yourself." });
    }

    const existingChat = await findDirectChat(senderId, receiverId);

    if (existingChat) {
      return res
        .status(400)
        .json({ message: "You are already in a chat with this user." });
    }

    const request = await ChatRequest.create({
      sender: senderId,
      receiver: receiverId,
    });

    const populatedRequest = await populateRequestById(request._id);

    const receiverSocketId = getReceiverSocketId(receiverId);
    if (receiverSocketId) {
      io.to(receiverSocketId).emit("newChatRequest", populatedRequest);
    }

    res.status(201).json({
      message: "Chat request sent.",
      request: populatedRequest,
    });
  } catch (err) {
    if (err.code === 11000) {
      return res.status(400).json({ message: "Chat request already pending." });
    }

    res.status(500).json({ message: "Server error", error: err.message });
  }
};

export const getIncomingRequests = async (req, res) => {
  try {
    const requests = await ChatRequest.find({
      receiver: req.user._id,
      status: "pending",
    })
      .populate("sender", "name email profilePic")
      .sort({ createdAt: -1 });

    res.status(200).json(requests);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
};

export const getPendingRequests = getIncomingRequests;

export const getOutgoingRequests = async (req, res) => {
  try {
    const requests = await ChatRequest.find({
      sender: req.user._id,
    })
      .populate("receiver", "name email profilePic")
      .sort({ updatedAt: -1, createdAt: -1 });

    res.status(200).json(requests);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
};

export const acceptChatRequest = async (req, res) => {
  try {
    const requestId = req.params.requestId || req.body.requestId;
    const request = await ChatRequest.findById(requestId);

    if (!request) {
      return res.status(404).json({ message: "Request not found." });
    }

    if (request.receiver.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Unauthorized." });
    }

    if (request.status !== "pending") {
      return res
        .status(400)
        .json({ message: `Request already ${request.status}.` });
    }

    request.status = "accepted";
    await request.save();

    await Promise.all([
      User.updateOne(
        { _id: request.sender },
        { $pull: { removedUsers: request.receiver } },
      ),
      User.updateOne(
        { _id: request.receiver },
        { $pull: { removedUsers: request.sender } },
      ),
    ]);

    const populatedRequest = await populateRequestById(request._id);

    let chat = await findDirectChat(request.sender, request.receiver);

    if (!chat) {
      chat = await Chat.create({
        isGroupChat: false,
        users: [request.sender, request.receiver],
      });
    }

    const fullChat = await populateChatById(chat._id);

    const senderSocketId = getReceiverSocketId(request.sender.toString());
    if (senderSocketId) {
      io.to(senderSocketId).emit("chatRequestAccepted", { chat: fullChat });
      io.to(senderSocketId).emit("chatRequestStatusChanged", {
        request: populatedRequest,
        chat: fullChat,
      });
      io.to(senderSocketId).emit("request_accepted", {
        message: "Your chat request was accepted!",
        request: populatedRequest,
        chat: fullChat,
      });
    }

    res.status(200).json({
      message: "Chat request accepted.",
      chat: fullChat,
    });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
};

export const rejectChatRequest = async (req, res) => {
  try {
    const requestId = req.params.requestId || req.body.requestId;
    const request = await ChatRequest.findById(requestId);

    if (!request) {
      return res.status(404).json({ message: "Request not found." });
    }

    if (request.receiver.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Unauthorized." });
    }

    if (request.status !== "pending") {
      return res
        .status(400)
        .json({ message: `Request already ${request.status}.` });
    }

    request.status = "rejected";
    await request.save();

    const populatedRequest = await populateRequestById(request._id);

    const senderSocketId = getReceiverSocketId(request.sender.toString());
    if (senderSocketId) {
      io.to(senderSocketId).emit("chatRequestStatusChanged", {
        request: populatedRequest,
      });
      io.to(senderSocketId).emit("request_rejected", {
        message: "Your chat request was rejected.",
        request: populatedRequest,
      });
    }

    res.status(200).json({ message: "Chat request rejected." });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
};

export const cancelChatRequest = async (req, res) => {
  try {
    const { requestId } = req.params;
    const request = await ChatRequest.findById(requestId);

    if (!request) {
      return res.status(404).json({ message: "Request not found." });
    }

    if (request.sender.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Unauthorized." });
    }

    if (request.status !== "pending") {
      return res
        .status(400)
        .json({ message: "Only pending requests can be cancelled." });
    }

    await request.deleteOne();

    res.status(200).json({ message: "Chat request cancelled." });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
};
